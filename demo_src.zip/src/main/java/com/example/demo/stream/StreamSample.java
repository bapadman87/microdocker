package com.example.demo.stream;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class StreamSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntStream.rangeClosed(1, 10)//IntStream
		.boxed()//<Stream<Integer>>
		.collect(Collectors.toList()).forEach(System.out::println);
		
		List<Integer> natNumList = IntStream.rangeClosed(1, 10)//IntStream
		.boxed()//<Stream<Integer>>
		.collect(Collectors.toList());
		
		Predicate<Integer> isEven = x -> x%2==0;
		Predicate<Integer> gt5 = x -> x>5;
		
		List<String> natStrList = natNumList.stream().filter(isEven.and(gt5))
		.map(x->Integer.toString(x))
		.collect(Collectors.toList());
		System.out.println(natStrList);
		
		
		
		Function<Map.Entry<Integer,Integer>,Map.Entry<Integer,Integer>> mul27 = entry -> Map.entry(entry.getKey(),entry.getValue()*27);
		Predicate<Map.Entry<Integer,Integer>> onlyEvenKeys = entry->entry.getKey()%2==0;
		natNumList.stream()
		.collect(Collectors.toMap(x->x, x->1,(x,y)->x+y))//keyMapper,ValueMapper,Merger
		.entrySet()
		.stream()
		.filter(onlyEvenKeys)
		//.map(entry -> Map.entry(entry.getKey(),entry.getValue()*27))
		.map(mul27)
		.forEach(entry->System.out.println(entry.getKey()+"<==>"+entry.getValue()));
		
		//reduce sample
		System.out.println(List.of("Ba","la","ji").stream().reduce((a,b)->a+b).get());
		System.out.println(List.of(1,2,3,4,5).stream().reduce((a,b)->a+b).get());
		System.out.println(List.of(1,2,3,4,5).stream().reduce(Integer::max).get());
		System.out.println(List.of(1,2,3,4,5).stream().reduce((a,b)->(a>b)?a:b).get());
		
		//groupingBy
		record Employee(String name,String dept) {}
		List<Employee> employees =
			    List.of(
			      new Employee("A","IT"),
			      new Employee("B","HR"),
			      new Employee("C","IT")
			    );
		employees.stream().collect(Collectors.groupingBy(Employee::dept)).entrySet()
		.stream().forEach(entry -> System.out.println(entry.getKey()+"<====>"+entry.getValue()));
		
		//flatMap
		//"dog","cat"
		List.of("dog","cat").stream()
		.flatMap(x->x.chars().mapToObj(c -> (char) c))//flatMap takes stream as input . chars give intstream . mapToObj converts it to char by casting
		.collect(Collectors.toList()).forEach(System.out::println);
		
		List.of(List.of(1,2,3),List.of(4,5,6)).stream()
		.flatMap(x->x.stream())//ListStream for each list 
		.forEach(System.out::println);
	}
}
