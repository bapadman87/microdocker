package com.example.demo.threadlocal;

import java.text.SimpleDateFormat;

public class ThreadLocalSample {
public static void main(String[] args) {
	
}
}

class SimpleDateGetter
{
	//public static ThreadLocal<SimpleDateFormat> tlDate = ThreadLocal.withInitial(()->{});
}
