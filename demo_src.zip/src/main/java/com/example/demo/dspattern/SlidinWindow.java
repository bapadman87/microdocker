package com.example.demo.dspattern;

import java.util.HashMap;
import java.util.Map;

public class SlidinWindow {
public static void main(String[] args) {
	System.out.println(MaxSumOfNUnsortedInts.maxSum(new int[] {1,4,2,10,23,3,1,0,20}, 4));
	System.out.println(LongestSubstrWithoutRepeatingChar.LongSubstr("abcabcbb"));
}
}


class MaxSumOfNUnsortedInts
{
	/*
	 * Maximum Sum of K Consecutive Elements
	 * 
	 * Input:
[1,4,2,10,23,3,1,0,20]
k = 4

Output:
39
	 */
	static int maxSum(int[] arr,int k) {
		//for int i = 0 to length -4 
		int initSum = 0,maxSum = 0;
		for(int i =0 ;i<k;i++)
		{
			initSum+=arr[i];
		}
		maxSum = initSum;
		for(int i=k;i<arr.length;i++)
		{
			int currMaxSum = maxSum+arr[i]-arr[i-k];
			maxSum = currMaxSum > maxSum ? currMaxSum : maxSum;
		}
		
		
	return maxSum;
}
}


class LongestSubstrWithoutRepeatingChar
{
	/*
	 * Input:
"abcabcbb"

Output:
3
	 * 
	 */
	static int LongSubstr(String ip)
	{
		char[] ipChars = ip.toCharArray();
		Map<Character,Integer> charToCountMap = new HashMap<>();
		int maxLen = 1 ,currLen = 0;
		for (char x:ipChars)
		{
			if(charToCountMap.get(x)==null)
				{ charToCountMap.put(x, 1);currLen++; }
			else
			    { 
				   maxLen = currLen > maxLen ? currLen:maxLen;
				   currLen = 0;
			    }
		}
		return maxLen;
	}
	
	
}