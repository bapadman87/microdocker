package com.example.demo.dspattern;

public class BinarySearch {
	
	static int binSearch(int[] ip,int x)
	{
		int pos =-1;
		
		int low = 0 , high = ip.length-1;
		
		while(low<=high)
		{
			int mid = (low+high)/2;
			if(ip[mid]==x)
			{
				return mid;
			}
			else if (ip[mid]<x)
			{
				low = mid+1; 
			}
			else
			{
				high =mid-1;
			}
		}
		return pos;
	}
	
	
	static int findFirst(int[] ip,int x)
	{
		int pos =-1;
		
		int low = 0 , high = ip.length-1;
		
		while(low<=high)
		{
			int mid = (low+high)/2;
			if(ip[mid]==x)
			{
				pos = mid;
				high = mid-1;
				//keep running the loop to find 
				//whether there is matching element in left of mid .
			}
			else if (ip[mid]<x)
			{
				low = mid+1; 
			}
			else
			{
				high =mid-1;
			}
		}
		return pos;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(binSearch(new int[] {2,3,4,5,6},3));
System.out.println(binSearch(new int[] {2,3,4,5,6},4));
System.out.println(binSearch(new int[] {2,3,4,5,6},5));
System.out.println(binSearch(new int[] {2,3,4,5,6,7},3));
System.out.println(binSearch(new int[] {2,3,4,5,6,7},4));
System.out.println(binSearch(new int[] {2,3,4,5,6,7},5));
System.out.println(binSearch(new int[] {2,3,4,5,6,7},6));
System.out.println(binSearch(new int[] {2,3,4,5,6,7},7));
System.out.println(binSearch(new int[] {2,3,4,5,6,7},8));



int[] arr = {1,2,2,2,3,4};
int target = 2;
System.out.println(findFirst(arr,target));

	}

}
