package com.example.demo.dspattern;

import java.util.Arrays;

public class TwoPointers {
public static void main(String[] args) {
	PairSumInSorted.printPair(new int[] {1,4,5,6,9},9);
	PairSumInSorted.printPair(new int[] {1,4,5,6,9},11);
	PairSumInSorted.printPair(new int[] {1,2,4,6,8,10},10);
	System.out.println(HappyNum.isHappy(29));
	System.out.println(Arrays.toString(RemoveDups.removeDups(new int[] {1,1,2,2,3,4,4})));
}
}

class PairSumInSorted
{
	/*
	Pair With Given Sum
	[1,2,4,6,8,10]#sorted
	target = 10
	2 + 8
	*/
	static void printPair(int input[],int target)
	{
		int leftPtr = 0;
		int rightPtr = input.length - 1;
		while(leftPtr<rightPtr)
		{
			if(target == input[leftPtr]+input[rightPtr])
			{
				System.out.println(input[leftPtr]+" <====> "+input[rightPtr]);
				break;
			}
			else if(target > input[leftPtr]+input[rightPtr])
			{
				leftPtr++;
			}
			else
			{
				rightPtr--;
			}
			
		}
	}
}



		
class RemoveDups
{
	/*
	 * Remove duplicates from sorted array 
	 * Input:
[1,1,2,2,3,4,4]
0,1,2,3
1,3,5,7

Output:
[1,2,3,4]

this s solved with fast and slow pointer 
slow = 0 fast =1
if same increase fasr
if different increase slow ,update slow , increase fast
	 */
	static int[] removeDups(int input[])
	{
		int iplen = input.length;
		
		int slow =0 ,fast=1;
		while(fast<iplen)
		{
		if(input[slow]!=input[fast])
		{
			input[++slow] = input[fast];
		}
		fast++;
		}
		return Arrays.copyOf(input, slow+1);
		
	}
}

class HappyNum
{
	static int nextNum(int n)
	{
		int nextNum = 0;
		do
		{
			int digit = n/10;
			nextNum += digit*digit;
			n = n / 10;
			
		}while(n%10>0);
		return nextNum;
	}
	
	public static boolean isHappy(int num)
	{
		int slow = num;
		int fast = nextNum(num);
		while(fast != 1 && slow!= fast)
		{
			slow = nextNum(slow);
			fast = nextNum(nextNum(fast));
		}
		
		return fast==1;
	}
}
