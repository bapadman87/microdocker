package com.example.demo.dspattern;

public class StringBased {
public static void main(String[] args) {
	CommonPrefix.printCommonChars(new String[] {"cool","cook","coob"});
}
}
class CommonPrefix
{
	//ip :=> cool,cook,coob
	//op :=> coo
	//hash based approach 
	/*
	 * create a map of index to char for first string
	 * 
	 * for all other string compare chars at index level 
	 * if mismatch at particular index level 
	 * delete key eq and above the index
	 */
	
	public static void printCommonChars(String[] ip)
	{
		//alternate simpler string based approach
		String prefix = ip[0];
		for(int i=1;i<ip.length;i++)
		{
			while(!ip[i].startsWith(prefix) && prefix.length() > 0)
			{
				prefix = prefix.substring(0,prefix.length()-1);
			}
		}
		System.out.println(" prefix "+prefix);
	}
	
}
