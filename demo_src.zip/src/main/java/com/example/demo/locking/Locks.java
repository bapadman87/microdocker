package com.example.demo.locking;

import java.util.concurrent.locks.ReentrantLock;

public class Locks {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		
		Counter ctr = new Counter();
				
		
		Runnable r = ()-> {
			int i =0;
			while(i<100){
			i = ctr.incrementCounter();
			System.out.println(Thread.currentThread().getName()+"=="+i);
			}
		};
		
		Thread t1= new Thread(r,"th1");
		t1.start();

		Thread t2= new Thread(r,"th2");
		t2.start();
		t1.join();
		t2.join();
		

	}

}


class Counter
{
	private int counter = 0;
	
	ReentrantLock lock = new ReentrantLock();
	
	public int incrementCounter()
	{
		lock.lock();
		try {
		counter++;
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		finally {
		lock.unlock();
		}
		return counter;
	}
}
