package com.example.demo.locking;

import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class CyclicBarrierTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		CyclicBarrier cb = new CyclicBarrier(5);
		
		ExecutorService es = Executors.newFixedThreadPool(5);
		for(int i=1;i<6;i++)
		es.submit(new Sprinter("Runner - "+i, cb));
		es.shutdown();
		es.awaitTermination(1, TimeUnit.MINUTES);
		System.out.println("End of race");
		
		
	}
	
	static class Sprinter implements Runnable
	{
		String name = null;CyclicBarrier cb = null;
		public Sprinter(String name,CyclicBarrier cb)
		{
			this.name = name;
			this.cb = cb;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println(name + " warming up ...");
			try {
				Thread.sleep(new Random().nextInt(5)*1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(name + " reading to race ...");
			try {
				cb.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BrokenBarrierException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(name + " racing ...");
			
		}
		
	}

}
