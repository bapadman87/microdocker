package com.example.demo.locking;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class SemaTest {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Semaphore capacity = new Semaphore(3);
		
		ExecutorService es = Executors.newFixedThreadPool(10);
		
		for(int i=0;i<10;i++)
		{
			CarParking c = new CarParking("car"+i,capacity);
			es.submit(c);
		}
		es.shutdown();
		es.awaitTermination(1, TimeUnit.MINUTES);
		System.out.println("End of main");
	}
	
	static class CarParking implements Runnable
	{
		Semaphore parkingLot = null;
		String carName = null;
		public CarParking(String carName,Semaphore parkingLot)
		{
			this.carName = carName;
			this.parkingLot = parkingLot;
		}
		
		@Override
		public void run()
		{
			try
			{
				parkingLot.acquire();
				System.out.println("Car "+carName+" parked at "+System.currentTimeMillis());
				Thread.sleep(3000);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			finally
			{				
				parkingLot.release();
				System.out.println("Car "+carName+" cleared at "+System.currentTimeMillis());
			}
			
		}
	}

}
