package com.example.demo.locking;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ProducerConsumerLock {
public static void main(String[] args) {
	
}
}

class MyQueue<T>
{
	//queue structure 
	Queue<T> queue = new LinkedList<T>();
	final int MAX_SIZE =10;
	Lock qLock = new ReentrantLock();
	Condition isNotFull = qLock.newCondition();
	Condition isNotEmpty = qLock.newCondition();
	
	public void addToQueue(T item) throws InterruptedException
	{
		qLock.lock();
		try
		{
			while(queue.size() == MAX_SIZE)
					isNotFull.await();
			queue.add(item);
			isNotEmpty.signal();
		}
		finally
		{
			qLock.unlock();
		}
	}
	
	public T readFromQueue() throws InterruptedException
	{
		T returnElement = null; 
		qLock.lock();
		try
		{
			while(queue.size() == 0)
				isNotEmpty.await();
			returnElement = queue.poll();
			isNotFull.signal();
		}
		finally
		{
			qLock.unlock();
		}
		return returnElement;
	}
	
}
