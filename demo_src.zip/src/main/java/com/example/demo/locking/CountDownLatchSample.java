package com.example.demo.locking;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain.Strategy.Fixed;

public class CountDownLatchSample {
	
	public static void main(String[] args) throws InterruptedException {
		CountDownLatch cdl = new CountDownLatch(3);
		Runnable r = () -> {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Count down thread ");
			cdl.countDown();
		};
		
		
		ExecutorService exs = Executors.newFixedThreadPool(5);
		int i=0;
		while(++i<4)
			exs.submit(r);
		
		cdl.await();
		System.out.println("wait ended ");
		exs.shutdown();
		
	}

}
