package com.example.dp;

import java.util.Stack;

class Phone
{
	private String phone1;
	private String phone2;
	public Phone(String phone1,String phone2)
	{
		this.phone1=phone1;
		this.phone2= phone2;
	}
	
	@Override
	public String toString() {
		return "Phone [phone1=" + phone1 + ", phone2=" + phone2 + "]";
	}
	
}

class Address
{	
	private String doorNo;
	private String streetName;
	private Phone phone;
	
	public void saveAddress(String doorNo, String streetName, Phone phone) {
		this.doorNo = doorNo;
		this.streetName = streetName;
		this.phone = phone;
		MomentoRepo.saveToRepo(new Momento(doorNo, streetName, phone));
	}
	
	public void revert() {
		Momento m = MomentoRepo.revert();
		this.doorNo = m.doorNo;
		this.streetName = m.streetName;
		this.phone = m.phone;		
	}
	
	
	
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", streetName=" + streetName + ", phone=" + phone + "]";
	}



	public class Momento
	{
		private final String doorNo;
		private final String streetName;
		private final Phone phone;
		
		public Momento(String doorNo,
		String streetName,
		Phone phone) {
			this.doorNo = doorNo;
			this.streetName = streetName;
			this.phone = phone;			
		}
		
	}
	
	
}

class MomentoRepo //careTaker
{
	static Stack<Address.Momento> repo = new Stack<>();
	
	public static void saveToRepo(Address.Momento momento)
	{
		repo.push(momento);
	}
	
	public static Address.Momento revert()
	{
		repo.pop();
		return repo.peek();
	}		
}
public class Memonto {
public static void main(String[] args) {
	System.out.println("hello ..");
	Phone p = new Phone("99529","84320");
	Address a = new Address();
	a.saveAddress("11", "vadivel", p);
	System.out.println(a);
	System.out.println("saved");
	a.saveAddress("10", "vadival", new Phone("12345","52342"));
	System.out.println(a);
	System.out.println("Updated");
	a.revert();
	System.out.println(a);
	System.out.println("Reverted");
	
}
}
