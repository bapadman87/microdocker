package com.example.springcore.d3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.springcore.d1.AppConfig;

/**
 * Bean scope samples
 *
 * @author bpadmanabhan
 *
 */
public class SpringApplicationD3 {
public static void main(String[] args) {
	
}
}
