package com.example.springcore.d2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.springcore.d1.AppConfig;

/**
 * Bean scope samples
 *
 * @author bpadmanabhan
 *
 */
public class SpringApplication {
public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(BeanScopeAppConfig.class);
	Counter ctr = (Counter) context.getBean("singly");
	System.out.println(ctr.getCount());
	int m=5;
	while(--m > 0)
		ctr.incrementCounter();
	System.out.println(ctr.getCount());
	
	Counter ctr2 = (Counter) context.getBean("singly");
	System.out.println(ctr2.getCount());
	m=5;
	while(--m > 0)
		ctr.incrementCounter();
	System.out.println(ctr2.getCount());
	
	System.out.println("Testing proto");
	
	
	Counter pro = (Counter) context.getBean("proto");
	System.out.println(pro.getCount());
	m=5;
	while(--m > 0)
		pro.incrementCounter();
	System.out.println(pro.getCount());
	
	Counter pro2 = (Counter) context.getBean("proto");
	System.out.println(pro2.getCount());
	m=5;
	while(--m > 0)
		pro2.incrementCounter();
	System.out.println(pro2.getCount());
	
	//Prototype injected in to singleton remains singleton 
	
	System.out.print("Proto injected in to singly");
	
	HopCounter hc = context.getBean(HopCounter.class);
	hc.runCounterIncrements();
	
	HopCounter hc2 = context.getBean(HopCounter.class);
	hc2.runCounterIncrements();
	
	
	
}
}
