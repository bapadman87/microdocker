package com.example.springcore.d2;

import javax.inject.Provider;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Configuration
@ComponentScan("com.example.springcore.d2")
public class BeanScopeAppConfig {
}

interface Counter
{
	int getCount();
	void incrementCounter();
}

@Component("singly")
class SingletonCounter implements Counter
{
	int count = 0;
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return count;
	}

	@Override
	public void incrementCounter() {
		// TODO Auto-generated method stub
		count++;
	}
	
}

@Component("proto")
@Scope("prototype")
@Primary
class PrototypeCounter implements Counter
{
	int count = 0;
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return count;
	}

	@Override
	public void incrementCounter() {
		// TODO Auto-generated method stub
		count++;
	}
}


//Injecting prototype into singleton
@Component
class HopCounter
{
	//workaround for below issue
	//this shall be provider with Spring Boot 
	//Plain provider is not autowire compatible -spring boot handler it
	//
	@Autowired
	private ObjectProvider<Counter> counterProvider;
			
	//@Autowired
	// Counter counter; //counter injected will always be singleton , inspite of that referring to prototype bean
	//Every time this HopCounter bean is initialized , It will always refer to that couter as singleton value
	
	public void runCounterIncrements()
	{
		Counter counter = counterProvider.getObject(); 
		for(int s =0;s<5;s++)
		{
			counter.incrementCounter();
			System.out.println("Prinitng hop counter "+counter.getCount());
		}
	}
}