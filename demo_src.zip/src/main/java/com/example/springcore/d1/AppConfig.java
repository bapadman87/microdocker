package com.example.springcore.d1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.example.springcore.d1.Engine;

@Configuration
@ComponentScan("com.example.springcore")
public class AppConfig {
}

interface Engine
{
	String fuelType();
}

@Component("petrol")
class PetrolEngine implements Engine
{
	@Override
	public String fuelType() {
		// TODO Auto-generated method stub
		return "Petrol";
	}
}

@Component
@Primary
class DieselEngine implements Engine
{
	@Override
	public String fuelType() {
		// TODO Auto-generated method stub
		return "Diesel";
	}
}

@Component
@Primary
class Car
{
	@Autowired
	@Qualifier("petrol")
	Engine engine;
	
	public void ignition()
	{
		System.out.println(engine.fuelType()+ " car started . ");
	}
}