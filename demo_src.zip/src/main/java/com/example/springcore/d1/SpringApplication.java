package com.example.springcore.d1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.example.springcore.d1.Car;

/**
 * Basic Depedency Injection and IOC Samples
 *
 * @author bpadmanabhan
 *
 */
public class SpringApplication {
public static void main(String[] args) {
	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
	Car car = context.getBean(Car.class);
	car.ignition();
}
}
