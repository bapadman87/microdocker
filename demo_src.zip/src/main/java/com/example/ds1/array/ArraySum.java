package com.example.ds1.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ArraySum {
	
	public static void otherTEsts() {

		// TODO Auto-generated method stub
		int input[] = new int[] {1,2,9,7};
		int sum = 11;
		Map<Integer,Integer> intarray = new HashMap<>();	
		intarray.put(input[0],0);
		for(int i = 1;i<input.length;i++)
		{
			Integer invIndex = intarray.get(sum-input[i]);
			if(invIndex!=null)
				System.out.println("Sum indices - "+i+","+invIndex);
			else
				intarray.put(input[i],i);
		}
		
		//max profit 
		int stock_prices[] = new int [] {7,1,5,3,6,4};
		int min = stock_prices[0] , max = stock_prices[0];
		for(int i=1;i<stock_prices.length;i++)
		{
			if(stock_prices[i] < min)
			{
				min = stock_prices[i] ; 
				max = stock_prices[i];
						
			}
			if(stock_prices[i] > max)
			{
				max = stock_prices[i];
			}
		}
		System.out.println("maxprofit "+(max-min));
		
		//find the length of the longest substring without repeating characters.
		
		String s = "abcabcbb",s2 ="abbda";
		
		char[] letters = s2.toCharArray();
		
		Set<String> longStr = new HashSet<String>();
		int maxStrSize =1;
		for(char x:letters)
		{
			if(longStr.contains(x+""))
			{
				longStr.remove(x);
			}
			longStr.add(x+"");
			maxStrSize = (maxStrSize < longStr.size())?longStr.size():maxStrSize;
		}
		
		System.out.println("long str size : "+maxStrSize);
		
		
		//#4: Remove Duplicates from Sorted Array with no extra space
		
		int nums[] = new int[] {0,0,1,1,1,2,2,3,3,4};
		int maxpos = 0 , maxval = nums[0];
		for(int i =1;i<nums.length;i++)
		{
			if(nums[i]>maxval)
			{
				nums[++maxpos]=nums[i];
				maxval = nums[i];
			}
		}
		for(int i = 0;i<=maxpos;i++)
			System.out.println(nums[i]);
	
	}

	public static void main(String[] args) {
		int m[] = new int[]{8,10,1,3,15,18,2,6};//[8,10], [1,3], [15,18], [2,6]
        for(int i=0;i<m.length-1;i+=2)
        	for(int j=i+2;j<m.length;j+=2)
        	{
        		if(m[i]>m[j])
        		{
        			int temp1 = m[i];
        			int temp2 = m[i+1];
        			
        			m[i] = m[j];
        			m[i+1] = m[j+1];
        			
        			m[j] = temp1;
        			m[j+1] = temp2;
        		}
        	}
        
        System.out.println(java.util.Arrays.toString(m));
        
        //other way using 2D array 
        
        int[][] intervals = { {8,10}, {1,3}, {15,18}, {2,6} };
        Arrays.sort(intervals,(a,b)->Integer.compare(a[0],b[0]));
        for(int[] intr : intervals)
        System.out.println(java.util.Arrays.toString(intr));
        
        for(int pt =0;pt<intervals.length-1;pt++)
        {
        	int[] left = intervals[pt];
        	int[] right = intervals[pt+1];
        	if(left[1]<right[0])
        		System.out.print(java.util.Arrays.toString(left)+ " , ");
        	else if(left[1]>right[0])
        	{
        		if(left[1]<right[1])
        		{
        			left[1]=right[1];
        			pt+=1;
        			System.out.print(java.util.Arrays.toString(left)+ " , ");
        		}
        		else
        		{
        			System.out.print(java.util.Arrays.toString(left)+ " , ");
        			pt+=1;
        		}
        	}
        	if(pt == intervals.length-2 )
        	{
        		System.out.println(java.util.Arrays.toString(right)+ " , ");
        	}
        }
        // selection sort
        // more like manual - pick the smallest and put in first position and so on .
        
        m = new int[]{8,10,1,3,15,18,2,6};
        
        for(int i=0;i<m.length-1;i++)
        {
        	int minidx = i;
        	for(int j=i+1;j<m.length;j++)
        	{
        		if(m[j]<m[minidx])
        		{
        			minidx = j;
        		}
        	}
        	int temp  = m[minidx];
        	m[minidx] = m[i];
        	m[i] = temp;
        }
        System.out.println(java.util.Arrays.toString(m));
        /*
         * intervals = [[1,2],[3,5],[6,7],[8,10],[12,16]]
		 * newInterval = [4,8]
         */
        
        List<int[]> intList = new ArrayList<>();
        int[][] intervals2 = {{1,2},{3,5},{6,7},{8,10},{12,16},{18,19}};
        int[] newInterval = {4,8};
        int[] merged = {-1,-1};boolean isMergeComplete = false; 
        for(int i=0;i<intervals2.length;i++)
        {
        	int[] currArr = intervals2[i];
        	if(currArr[1]<newInterval[0])
        	{
        		intList.add(currArr);
        	}
        	else if(currArr[0]>newInterval[1])
        	{
        		if(!isMergeComplete)
        		{
        		intList.add(merged);
        		isMergeComplete = true;
        		}
        		intList.add(currArr);
        	}
        	else
        	{
        		merged[0] = merged[0] == -1 ? Math.min(newInterval[0], currArr[0]):merged[0];
                merged[1] = Math.max(newInterval[1], currArr[1]); 
        	}
        	
        }
        
        if (!isMergeComplete) {
            intList.add(merged);
        }

        
        for(int[] x : intList)
        System.out.println("Priinting final list "+ java.util.Arrays.toString(x));
        
        
 
        
	}

}
