package com.example.ds1.array;

import java.util.HashMap;
import java.util.Map;

public class LRUCache {

	static class DLL {
		int capacity = 0;
		DLLNode head = null ,tail = null;
		
		public DLLNode addNode(Character x )
		{
			ensureCapacity();
			DLLNode newNode = new DLLNode(null,x,null);
			if(head == null)
			{
				head = newNode;
			}
			if(tail != null)
			{
				tail.next = newNode;
				newNode.prev = tail;
			}
			tail = newNode ; 
			
			++capacity;
			return newNode;
		}
		
		public void ensureCapacity()
		{
			while(capacity >= 3)
			{
				// pop head 
				
				head = head.next;
				head.prev = null;
				// reduce capacity
				--capacity;					
			}
		}
		
		public void moveToTail(DLLNode x)
		{
			if(!tail.data.equals(x.data))
			{
			x.prev = tail;
			tail.next=x;
			tail = x;
			tail.next = null;
			if(x.data.equals(head.data))
			{
				head = head.next;
				head.prev = null;
			}
			}
		}
		
		public void printList()
		{
			DLLNode m = head;
			do {
				System.out.print(m.data + " => ");
				m = m.next;
			}while(m != null);
			System.out.println();
		}
	}
	
	static class DLLNode {
		DLLNode prev , next;
		Character data;
		
		public DLLNode(DLLNode prev , Character data , DLLNode next)
		{
			this.prev = prev;
			this.data = data;
			this.next = next;
		}
	}
	
	static class Cache {
		Map<Character , DLLNode> cacheMap = new HashMap<Character , DLLNode>();
		DLL dllOps = new DLL();
			
		public void addToCache(Character x)
		{
			System.out.println("Addting to cahec : "+x);
			DLLNode nodeInList = cacheMap.get(x);
			if(nodeInList == null)
			{
				System.out.println("creating Node "+x);
				DLLNode newNode = dllOps.addNode(x);
				cacheMap.put(x, newNode); 
			}
			else
			{
				System.out.println("Node in list ");
				dllOps.moveToTail(nodeInList);
			}
			
			dllOps.printList();
		}
		
	}
	
	public static void main(String[] args) {
		String test = "assassination";
		Cache cache = new Cache();
		for(Character x : test.toCharArray())
		{
			cache.addToCache(x);
		}
	}
}
